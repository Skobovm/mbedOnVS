
extern "C"
{
	// User's C interop code goes here

	// Dummy function used in Program.cs as an example
	int AddOneInterop(int input)
	{
		return input + 1;
	}
}
