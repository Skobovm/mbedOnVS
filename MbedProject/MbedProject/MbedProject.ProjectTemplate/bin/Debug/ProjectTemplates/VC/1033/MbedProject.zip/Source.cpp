
extern "C"
{
    int main()
    {

    }
}
